<?php
// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar y procesar los datos del formulario
    $usuario = validar_input($_POST["usuario"]);
    $correo = validar_input($_POST["correo"]);
    $contrasena = validar_input($_POST["contrasena"]);
    $confirmar_contrasena = validar_input($_POST["confirmar_contrasena"]);

    // Verificar si las contraseñas coinciden
    if ($contrasena === $confirmar_contrasena) {
        // Hash de la contraseña antes de almacenarla en la base de datos (mejora la seguridad)
        $hashed_password = password_hash($contrasena, PASSWORD_DEFAULT);

        // Conexión a la base de datos (reemplaza 'nombre_de_la_base_de_datos' y 'tu_tabla' con tus valores)
        $conn = new mysqli('localhost', 'root', '', 'test');

        // Verificar la conexión
        if ($conn->connect_error) {
            die("Error en la conexión a la base de datos: " . $conn->connect_error);
        }

        // Inserción de datos en la base de datos
        $sql = "INSERT INTO test.registros (usuario, correo, contrasena) VALUES ('$usuario', '$correo', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {
            // Registro exitoso, redirigir al usuario al login
            header("Location: login.php");
            exit();
        } else {
            echo "Error en la inserción de datos: " . $conn->error;
        }

        // Cerrar la conexión a la base de datos
        $conn->close();
    } else {
        echo "Las contraseñas no coinciden. Inténtalo de nuevo.";
    }
}

// Función para limpiar y validar datos de entrada
function validar_input($dato) {
    $dato = trim($dato);
    $dato = stripslashes($dato);
    $dato = htmlspecialchars($dato);
    return $dato;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
</head>
<body>

<h2>Registro de Usuario</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="usuario">Nombre de Usuario:</label>
    <input type="text" name="usuario" required>
    <br><br>

    <label for="correo">Correo electrónico:</label>
    <input type="email" name="correo" required>
    <br><br>

    <label for="contrasena">Contraseña:</label>
    <input type="password" name="contrasena" required>
    <br><br>

    <label for="confirmar_contrasena">Confirmar Contraseña:</label>
    <input type="password" name="confirmar_contrasena" required>
    <br><br>

    <input type="submit" value="Registrar">
</form>

<p>¿Ya tienes cuenta? <a href='login.php'>Inicia sesión</a></p>

</body>
</html>


