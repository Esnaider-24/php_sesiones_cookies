<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['correo'])) {
    // Redirigir al usuario al login si no está autenticado
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archivos Protegidos</title>
</head>
<body>

<h2>Archivos Protegidos</h2>

<?php
// Lista de archivos PDF protegidos
$archivos_protegidos = [
    'archivo1.pdf',
    'archivo2.pdf',
    'archivo3.pdf',
];

foreach ($archivos_protegidos as $archivo) {
    echo "<p><a href='ver_archivo.php?archivo=$archivo' target='_blank'>$archivo</a></p>";
}

?>

</body>
</html>

