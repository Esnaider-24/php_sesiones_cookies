<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Principal</title>
</head>
<body>

<h2>Página Principal</h2>

<p>Esta es la página principal. Puedes editar este párrafo según tus necesidades.</p>

<a href="recurso.php">Ir a la página de recursos</a>

</body>
</html>


