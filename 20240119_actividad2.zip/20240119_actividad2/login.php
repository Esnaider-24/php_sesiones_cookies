<?php
// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar y procesar los datos del formulario
    $correo = validar_input($_POST["correo"]);
    $contrasena = validar_input($_POST["contrasena"]);

    // Conexión a la base de datos (reemplaza 'nombre_de_la_base_de_datos' y 'tu_tabla' con tus valores)
    $conn = new mysqli('localhost', 'root', '', 'test');

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error en la conexión a la base de datos: " . $conn->connect_error);
    }

    // Consulta para obtener la contraseña almacenada asociada al correo proporcionado
    $sql = "SELECT correo, contrasena FROM test.registros WHERE correo = '$correo'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $hashed_password = $row['contrasena'];

        // Verifica la contraseña proporcionada con la contraseña almacenada
        if (password_verify($contrasena, $hashed_password)) {
            // Inicia la sesión y almacena el correo del usuario autenticado
            session_start();
            $_SESSION['correo'] = $correo;

            // Redirige a la página restringida
            header("Location: recurso.php");
            exit();
        } else {
            $error_message = "Contraseña incorrecta. Inténtalo de nuevo.";
        }
    } else {
        $error_message = "Usuario no encontrado. <a href='registro.php'>Regístrate</a> si aún no lo has hecho.";
    }

    // Cerrar la conexión a la base de datos
    $conn->close();
}

// Función para limpiar y validar datos de entrada
function validar_input($dato) {
    $dato = trim($dato);
    $dato = stripslashes($dato);
    $dato = htmlspecialchars($dato);
    return $dato;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>

<h2>Login</h2>

<?php
// Mostrar mensaje de error si existe
if (isset($error_message)) {
    echo "<p style='color:red;'>$error_message</p>";
}
?>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="correo">Correo electrónico:</label>
    <input type="email" name="correo" required>
    <br><br>

    <label for="contrasena">Contraseña:</label>
    <input type="password" name="contrasena" required>
    <br><br>

    <input type="submit" value="Iniciar sesión">
</form>

<!-- Agregar un botón que redirige a la página de registro -->
<p>¿No tienes cuenta? <a href='registro.php'>Regístrate</a></p>

</body>
</html>
